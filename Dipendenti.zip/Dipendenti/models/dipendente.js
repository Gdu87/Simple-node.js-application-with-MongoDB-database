const mongoose = require('mongoose')
mongoose.set('useCreateIndex', true);

const dipendentiSchema = new mongoose.Schema({
    nome: {
        type: String,
        required: true
    },
    cognome: {
        type: String,
        required: true
    },
    dataNascita: {
        type: Date,
        required: true
    },
    codFiscale: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    amministratore: {
        type: Boolean,
        default: false
    },
    ferieResidue: {
        type: Number,
        deafult:30
    },
    richiestaFerie: [{
        dataInizio: { 
            type: Date,
        },
        dataFine: { 
            type: Date,
        },
        numGiorni: { type: Number },
        stato: {
            type: Boolean,
            default:false
        }
    }]
},{ collection: 'Dipendente' })


module.exports=mongoose.model('Dipendente',dipendentiSchema)