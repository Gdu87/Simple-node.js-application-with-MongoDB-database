# Dipendenti

## Parole chiave

MongoDB, node.js, javascript, passport, html, css.

## Descrizione

Applicazione web based per la gestione delle ferie dei dipendenti aziendali. Dopo aver eseguito il login l'utente può essere loggato come amministratore o utente normale. L'amministratore può inserire nuovi dipendenti nel database e approvare le richieste di ferie pervenute. I dipendenti (normal users) possono richiedere dei giorni di ferie (nei limiti della loro disponibilità annuale, pari a 30 giorni) e cancellare le richieste non ancora approvate dall'amministratore. Il pannello di controllo dell'amministratore mostra costantemente l'elenco dei dipendenti e delle richieste, sia approvate che in attesa di approvazione. Il pannello del dipendente mostra l'elenco di tutte le richieste inviate e il relativo stato. I dati degli utenti sono conservati su cluster Atlas.

## Prima esecuzione

* Estrarre il contenuto del file zip (ad esempio nella cartella Documenti). Si otterrà la cartella Dipendenti contenente il progetto

* Aprire il prompt dei comandi di Windows (mediante Esegui, digitare cmd e premere invio)

* Posizionarsi nella directory `cd Dipendenti`

* Digitare `npm start`

* Aprire il browser e digitare nella barra degli indirizzi: `localhost:3000`

* Benvenuto nella pagina di Login!

## Usage

### Database

L'applicazione utilizza MongoDb su cluster Atlas. Il database, dopo aver creato un account su [MongoDB](https://www.mongodb.com/cloud/atlas/lp/try2?utm_source=google&utm_campaign=gs_emea_italy_search_core_brand_atlas_desktop&utm_term=mongodb&utm_medium=cpc_paid_search&utm_ad=e&utm_ad_campaign_id=12212624533&gclid=EAIaIQobChMIk5j8yZKV8QIVk5KyCh2_fgliEAAYASAAEgJa6vD_BwE), può essere creato sia da CLI che tramite GUI [Compass](https://www.mongodb.com/try/download/compass)

* CLI
Per creare un nuovo database usando la CLI digitare `use Dipendenti`, e inserire almeno il primo utente amministratore: `db.Dipendenti.insert({"nome":"Guido","cognome":"Iannone","dataNascita":{"$date":"1987-01-01T23:00:00.000Z"},"codFiscale":"NNNGDU87A01L682W","password":"$2b$10$5UkSEDQRTMkkcwUe2WJCFe1SzGVWRqOd0C2ZO37Wvw58ncE.DSdia","email":"guido.iannone@gmail.com","amministratore":true,"ferieResidue":30,"richiestaFerie":[]})`. Controllora che l'inserimento sia andato a buon fine con il comando `show dbs`

* GUI
Nella GUI compass, dopo aver inserito la stringa di connessione presa dal cloud, cliccare sul comando `CREATE DATABASE`, inserire il nome del database `Dipendenti` e il nome della prima collezione `Dipendente`. Cliccare sulla collezione appena creata e quindi sul tasto verde `ADD DATA`. Scegliere `insert document` e inserire almeno il primo utente amministratore  `db.Dipendenti.insert({"nome":"Guido","cognome":"Iannone","dataNascita":{"$date":"1987-01-01T23:00:00.000Z"},"codFiscale":"NNNGDU87A01L682W","password":"$2b$10$5UkSEDQRTMkkcwUe2WJCFe1SzGVWRqOd0C2ZO37Wvw58ncE.DSdia","email":"guido.iannone@gmail.com","amministratore":true,"ferieResidue":30,"richiestaFerie":[]})`.

ATTENZIONE: per evitare problemi di inconsitenza dei dati, si consiglia di creare anche il JSON schema dalla scheda `validation` di MongoDB compass. Per informazioni su come creare il JSON schema cliccare [qui](https://docs.mongodb.com/manual/core/schema-validation/)

### Client-side

L'unica richiesta lato client è quella di avere un browser internet. Nel caso di utilizzo da smartphone impostare il browser in modalità sito desktop. Per ulteriori informazioni vedere la sezioni Requisiti.

### Sever-side

Il database usato dall'applicazione è mongodb su cluster Atlas: non server avere mongodb compass installato, dato che i dati si trovano su cloud. La connessione con il database è pre-impostata e gestita in maniera totalmente automatizzata dall'applicazione.
Non sono richiesti particolari requisiti hardware.
Nel caso si desiderasse riusare questa applicazione con un proprio database cambiare la connection-String contenuta nel file .env

## Requisiti

Questa applicazione richiede l'installazione delle seguente dipendenze:

* "bcrypt": "^5.0.1"
* "express": "^4.17.1"
* "express-flash": "0.0.2"
* "express-handlebars": "^5.3.2"
* "express-session": "^1.17.2"
* "handlebars": "^4.7.7"
* "method-override": "^3.0.0"
* "mongoose": "^5.12.12"
* "mongoose-type-email": "^1.1.2"
* "passport": "^0.4.1"
* "passport-local": "^1.0.0"

Se hai scaricato l'applicazione e intendi modificarla, devi prima scaricare [node.js](https://nodejs.org/it/download/) o [VisualStudio Code](https://code.visualstudio.com/download). Dalla console, per installare tutte le dipendenze richieste, digita "npm i bcrypt express express-flash express-handlebars express-session handlebars method-ovveride mongoose mongoose-type-email passport passport-local" e premi il tasto invio. Per esguirla in developer mode, dopo l'installazione delle dipendenze digita `npm run devStart`, quindi apri il browser all'indirizzo `localhost:3000` per visualizzare la pagina di login.

## Funzionamento

Dopo l'inserimento del dipendente da parte dell'amministratore, questi può effettuare il login utilizzando una password di default ("prova"). La password è salvata su database criptata (utilizzando bcrypt). Il login viene effettuato confrontando l'Email e la password inserite nel form con i dati contenuti nei vari documenti della collezione mongodb usata dall'applicazione. La password viene confrontata utilizzando l'utilità compare offerta da bcrypt.

* Per accedere come amministratore Email: guido.iannone@gmail.com Password: prova

* Per accedere come dipendente inserire un qualunque dipendente dall'admin panel o utilizzare il dipendente pre inserito (marco.aurelio@gmail.com)

## Licenza

The ISC License (ISC)

«Copyright (c) 2021, Iannone Guido <guido.iannone@gmail.com>

Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
