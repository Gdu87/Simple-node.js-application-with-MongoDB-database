if (process.env.MODE_ENV !== 'production') {
    require('dotenv').config()
}


//parte funzionale dell'app
const express = require('express')
const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const hbs = require('express-handlebars')
const methodOverride = require('method-override')
const localStrategy = require('passport-local').Strategy
const bcrypt = require('bcrypt')
const mongoose = require('mongoose')
const app = express()
const Dipendente = require('./models/dipendente')
mongoose.connect(process.env.DATABASE_URL, { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false })
const db = mongoose.connection
db.on('error', (error) => console.error(error))
db.once('open', () => console.log('connesso al database'))

//middleware
app.engine('hbs', hbs({ extname: '.hbs' }))
app.set('view engine', 'hbs')
//imposto che l'uso dell'app è pubblico
app.use(express.static(__dirname + '/public'))
app.use(session({
    secret: "supercalifragili",
    resave: false,
    saveUninitialized: true
}))
app.use(express.urlencoded({ extended: false }))
app.use(express.json())

//passport.js
app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))
app.use(flash())

passport.serializeUser(function (dipendente, done) {
    done(null, dipendente.id);
})

passport.deserializeUser(function (id, done) {
    Dipendente.findById(id, function (err, dipendente) {
        done(err, dipendente);
    })
})

passport.use(new localStrategy({ usernameField: 'email', passwordField: 'password' }, function (email, password, done) {
    Dipendente.findOne({ email: email }, function (err, dipendente) {
        if (err) return done(err);
        if (!dipendente) return done(null, false, { error: 'email errata' });

        bcrypt.compare(password, dipendente.password, function (err, res) {
            if (err) return done(err);
            if (res === false) return done(null, false, { error: 'password errata' });
            return done(null, dipendente);
        });
    });
}));

//creo una funzione per controllore se l'utente è loggato
//se non è loggato va alla pagina di login
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated()) return next();
    res.redirect('/login');
}

function isLoggedOut(req, res, next) {
    if (!req.isAuthenticated()) return next();
    res.redirect('/');
}

//Creo una funzione per controllare se l'utente è Admin
function allowAdmins(req, res, next) {
    if (req.user.amministratore === true) return next();
    res.redirect('/');
}
//creo una funzione per controllare se l'utente è normale  
function allowRegular(req, res, next) {
    if (req.user.amministratore === false) return next();
    res.redirect('/admin');
}


//ROUTES
//route per pagina dipendente -index 
app.get('/', isLoggedIn, allowRegular, (req, res) => {
    Dipendente.findOne({ _id: req.user.id }, function (err, dipendente) {
        if (err) throw err, console.log("errore");
        res.render('index', { title: "Home", dipendente: dipendente });
    }).lean();
})

//route per pagina admin
app.get('/admin', isLoggedIn, allowAdmins, (req, res) => {
    Dipendente.find({}, function (err, dipendente) {
        if (err) throw err;
        res.render('admin', { title: "Admin", dipendente: dipendente });
    }).lean();
})

app.get('/login', isLoggedOut, (req, res) => {
    const response = {
        title: "login",
        error: req.query.error
    }
    res.render('login', response)
})

//gestisco i dati dal form di login per effettuare il login
app.post('/login', passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: '/login?error=true'
}))

app.get('/logout', function (req, res) {
    req.logout();
    res.redirect('/');
})


app.listen(3000, () => {
    console.log('in ascolto sulla porta 3000')
})

//route per inserimento dei dipendenti dalla pagina admin
app.post('/admin', isLoggedIn, allowAdmins, async (req, res) => {
    try {
        const hashedPassword = await bcrypt.hash("prova", 10)
        var date = req.body.dataNascita;
        var datearray = date.split("-");
        var newdate = datearray[1] + '/' + datearray[2] + '/' + datearray[0] + " 08:00"
        const dipendente = new Dipendente({
            nome: req.body.nome,
            cognome: req.body.cognome,
            dataNascita: newdate,
            codFiscale: req.body.codFiscale,
            password: hashedPassword,
            email: req.body.email,
            amministratore: false,
            ferieResidue: 30
        })
        await dipendente.save()
        Dipendente.find({}, function (err, dipendente) {
            if (err) throw err;
            // estraggo la lista di tutti i dipendenti
            res.render('admin', { title: "Admin", success: "Dipendente inserito correttamente", dipendente: dipendente });
        }).lean();
    } catch (err) {
        Dipendente.find({}, function (err, dipendente) {
            if (err) throw err;
            // estraggo la lista di tutti i dipendenti
            res.render('admin', { title: "Admin", error: "Dipendente non inserito, controllare i dati", dipendente: dipendente });
        }).lean();
    }
})

//route per inserimento della richiesta ferie
app.put('/:id', isLoggedIn, allowRegular, async (req, res, next) => {
    var dateIn = req.body.dataInizio;
    var dateFin = req.body.dataFine;
    var datearrayI = dateIn.split("-");
    var datearrayF = dateFin.split("-");
    var newdateI = datearrayI[1] + '/' + datearrayI[2] + '/' + datearrayI[0] + " 08:00";
    var newdateF = datearrayF[1] + '/' + datearrayF[2] + '/' + datearrayF[0] + " 20:00";
    var data1 = new Date(newdateI)
    var data2 = new Date(newdateF)
    var diffTime = data2.getTime() - data1.getTime();
    var giorni = (Math.round(diffTime / (1000 * 60 * 60 * 24)));
    let dipendente
    try {
        dipendente = await Dipendente.findById(req.user.id)
        if (dipendente == null) {
            res.render('index', { title: "Home", errore: "Richiesta non inserita, dipendente non trovato", dipendente: dipendente });
        }
    } catch (err) {
        res.render('index', { title: "Home", errore: "Richiesta non inserita, controllare i dati", dipendente: dipendente });
    }
    try {
        if (dipendente.ferieResidue < giorni) {
            Dipendente.findOne({ _id: req.user.id }, function (err, dipendente) {
                if (err) throw err, res.render('index', { errore: "Richiesta non inserita, giorni richiesti maggiori della disponibilità", dipendente: dipendente });
                res.render('index', { title: "Home", errore: "Richiesta non inserita, giorni richiesti maggiori della disponibilità", dipendente: dipendente });
            }).lean();
        }
        else if(giorni < 1) {
            Dipendente.findOne({ _id: req.user.id }, function (err, dipendente) {
                if (err) throw err, res.render('index', { errore: "Richiesta non inserita, controllare le date ", dipendente: dipendente });
                res.render('index', { title: "Home", errore: "Richiesta non inserita, controllare le date", dipendente: dipendente });
            }).lean();
        }
        else if(data1 < new Date()) {
            Dipendente.findOne({ _id: req.user.id }, function (err, dipendente) {
                if (err) throw err, res.render('index', { errore: "Non è possibile inserire richieste relative al passato o alla data odierna", dipendente: dipendente });
                res.render('index', { title: "Home", errore: "Non è possibile inserire richieste relative al passato o alla data odierna", dipendente: dipendente });
            }).lean();
        }
        else {
            dipendente.richiestaFerie.push({
                dataInizio: newdateI,
                dataFine: newdateF,
                numGiorni: giorni,
                stato: false
            })
            await dipendente.save()
            Dipendente.findOne({ _id: req.user.id }, function (err, dipendente) {
                if (err) throw err, res.render('index', { errore: "Richiesta non inserita, controllare i dati", dipendente: dipendente });
                // object of all the users
                res.render('index', { title: "Home", successo: "Richiesta ferie inserita correttamente", dipendente: dipendente });
            }).lean();
        }
    } catch (err) {
        Dipendente.findOne({ _id: req.user.id }, function (err, dipendente) {
            if (err) throw err, res.render('index', { errore: "Richiesta non inserita, controllare i dati", dipendente: dipendente });
            // object of all the users
            res.render('index', { title: "Home", errore: "Richiesta non inserita, controllare i dati", dipendente: dipendente });
        }).lean();
    }
})

//route per delete del dipendente
app.get('/:id', isLoggedIn, allowRegular, function (req, res) {
    try {
        Dipendente.updateOne(
            { _id: req.user.id },
            {
                $pull: {
                    richiestaFerie: { _id: req.params.id }
                }
            },
            { safe: true },
            function removeConnectionsCB(err, obj) {
            }
        );
        Dipendente.findOne({ _id: req.user.id }, function (err, dipendente) {
            if (err) throw err, res.render('index', { title: "Home", successo: "Richiesta ferie cancellata con successo", dipendente: dipendente });;
            res.render('index', { title: "Home", successo: "Richiesta ferie cancellata con successo", dipendente: dipendente });
        }).lean();
    } catch (err) {
        Dipendente.findOne({ _id: req.user.id }, function (err, dipendente) {
            if (err) throw err, res.render('index', { title: "Home", errore: "Non è possibile eliminare la richiesta", dipendente: dipendente });
            res.render('index', { title: "Home", errore: "Non è possibile eliminare la richiesta", dipendente: dipendente });
        }).lean();
    }
});

//route per approvazione richiesta ferie
app.patch('/admin', isLoggedIn, allowAdmins, function (req, res) {
    newDays = (req.body.ferieResidue - req.body.giorni);
    if (newDays < 0) {
        Dipendente.find({}, function (err, dipendente) {
            if (err) throw err, res.render('admin', { title: "Admin", errore: "Giorni richiesti maggiori del residuo ferie", dipendente: dipendente });;
            res.render('admin', { title: "Admin", errore: "Giorni richiesti maggiori del residuo ferie", dipendente: dipendente });
        }).lean()
    }
    else {
        try {
            Dipendente.updateOne(
                { _id: req.body.id },
                { $set: { "ferieResidue": newDays } },
                function (err, res) { console.log("aggiornamento effettuato") }
            );
            Dipendente.updateOne(
                { "richiestaFerie._id": req.body.rf_id },
                { $set: { "richiestaFerie.$.stato": true } },
                function (err, res) { console.log("aggiornamento array effettuato") }
            );
        } catch (e) {
            Dipendente.find({}, function (err, dipendente) {
                if (err) throw err, res.render('admin', { title: "Admin", errore: "Errore interno durante l'aggiornamento", dipendente: dipendente });;
                res.render('admin', { title: "Admin", errore: "Errore interno durante l'aggiornamento", dipendente: dipendente });
            }).lean()
        }
        Dipendente.find({}, function (err, dipendente) {
            if (err) throw err, res.render('admin', { title: "Admin", errore: "Errore interno durante l'aggiornamento", dipendente: dipendente });;
            res.render('admin', { title: "Admin", successo: "Ferie approvate correttamente", dipendente: dipendente });
        }).lean()
    }
});

